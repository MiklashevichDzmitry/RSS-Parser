//
//  NewsTableViewController.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 1/5/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import Foundation

class NewsTableViewController: UI

{
    
    
    
}

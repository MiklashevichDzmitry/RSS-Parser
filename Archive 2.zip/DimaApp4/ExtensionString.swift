//
//  ExtensionString.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 1/27/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import Foundation

extension String {
    
    public func editedNewsDescription() -> String {
        var editedDescription: NSString = self as NSString
        
        if editedDescription.contains("<img src") && editedDescription.contains("<br") {
            
            var substringStart = editedDescription.range(of: "<img src")
            var substirngEnd = editedDescription.range(of: "/>")
            var range = NSRange(location: substringStart.location, length: (substirngEnd.location + substirngEnd.length) - substringStart.location)
            
            editedDescription = editedDescription.replacingCharacters(in: range, with: "") as NSString
            
            substringStart = editedDescription.range(of: "<br")
            substirngEnd = editedDescription.range(of: "/>")
            range = NSRange(location: substringStart.location, length: (substirngEnd.location + substirngEnd.length) - substringStart.location)
            
            editedDescription = editedDescription.replacingCharacters(in: range, with: "") as NSString
        }
        
        if editedDescription.contains("\n\t\t") {
            editedDescription = editedDescription.replacingCharacters(in: NSRange(location: 0, length: 3), with: "") as NSString
        }
        return editedDescription as String
    }
    
    public func editedNewsDateOrTitle() -> String {
        var editedDataOrTitle: NSString = self as NSString
        if editedDataOrTitle.contains("\n\t\t"){
            editedDataOrTitle = editedDataOrTitle.replacingCharacters(in: NSRange(location: 0, length: 3), with: "") as NSString
        }
        if editedDataOrTitle.contains("+0300") {
            editedDataOrTitle = editedDataOrTitle.replacingCharacters(in: NSRange(location: editedDataOrTitle.length - 9, length: 9), with: "") as NSString
        }
        return editedDataOrTitle as String
    }
}

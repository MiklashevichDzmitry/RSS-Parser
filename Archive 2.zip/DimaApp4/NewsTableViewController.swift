//
//  NewsTableViewController.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 1/5/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import UIKit

class NewsTableViewController: UITableViewController, NewsLoaderDelegate {
    
    var selectedIndex: Int = 1
    var currentNews: [NewsItem]?
    var newsLoader: NewsLoader
    var parser: Parser
    var string: NSString
    let newsTableViewCell = NewsTableViewCell()
    
    required init?(coder aDecoder: NSCoder) {
        self.string = NSString()
        self.parser = Parser()
        self.newsLoader = NewsLoader()
        super.init(coder: aDecoder)
        self.newsLoader.delegate = self
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reloadData()
        self.refreshControl?.addTarget(self, action: #selector(NewsTableViewController.reloadData), for: UIControlEvents.valueChanged)
        newsLoader.loadNews()
    }
    
    func reloadData() {
        newsLoader.loadNews()
    }
    
    func refreshUI() {
        
        tableView.reloadData()
        refreshControl?.endRefreshing()
       
    }

    func didLoadNews(news: [NewsItem]) {
        currentNews = news
        refreshUI()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if let currentNews = currentNews{
            return currentNews.count
        } else {
            return 0
 
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellIdentifier = "NewsTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? NewsTableViewCell else {
            fatalError("The dequeued cell is not an instance of NewsTableViewCell.")
        }
        
        
        let item = currentNews![indexPath.row]
        if let date = item.date{
            if let newsTitle = item.newsTitle{
                cell.dateLabel.text = String(describing: date)
                cell.titleLabel.text = newsTitle
                cell.newsImage.imageFromUrl(urlString: item.imageURL!)
            }
            
        }else {
            print("Null")
        }
       
         return cell
        }


    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedIndex = indexPath.row
        performSegue(withIdentifier: "detailSegue", sender: self)
        
    }
        
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "detailSegue") {
            let detailViewController = segue.destination as! DetailViewController
            detailViewController.newsItem = currentNews![selectedIndex]
            
        }
    }
}













//
//  ViewController.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 12/29/16.
//  Copyright © 2016 Dzmitry Miklashevich. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController, UIScrollViewDelegate {
    
    var newsItem: NewsItem?
    
    @IBOutlet weak var detailImage: LoadingImageView!
    @IBOutlet weak var shortDescriptionLabel: UILabel!
    @IBAction func sourceButton(_ sender: AnyObject) {
        if let newsItemLink = newsItem?.link {
            print("\(newsItemLink)")
            if let url = URL(string: newsItemLink){
                print("\(newsItemLink)")
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
}

    override func viewWillAppear(_ animated: Bool) {
        
        if let newsItem = newsItem{
            shortDescriptionLabel.text = newsItem.shortDescription
        }
        
        if let newsItemImageUrl = newsItem?.imageURL{
            detailImage.imageFromUrl(urlString: newsItemImageUrl)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
}






//
//  Parser.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 1/24/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import Foundation
import UIKit

class Parser: NSObject, XMLParserDelegate {
    
    
    
    
    var parser: XMLParser?
    var insideAnItem = false
    var currentNewsItem: NewsItem?
    var currentElement = ""
    var currentAttributes = [String:String]()
    
    var newsDescription = ""
    var newsDate = ""
    var newsImageUrl = ""
    var newsLink = ""
    var newsTitle = ""
    
    
    var parsedNews = [NewsItem]()

    
    
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI namespaceURL: String?, qualifiedName qName: String?, attributes attributeDict: [String:String]){
        
        currentElement = elementName
        currentAttributes = attributeDict
        
        if elementName == "item"{
            currentNewsItem = NewsItem()
            insideAnItem = true
        }
        if elementName == "enclosure"{
            if let imageURL = currentAttributes["url"]{
                newsImageUrl = imageURL
            }
        }
        
    }
    
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        
        switch currentElement {
            case "title": newsTitle += string
            case "description": newsDescription += string
            case "link": newsLink += string
            case "pubDate": newsDate += string
        default: break
        }
        
    }
    
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        
        switch elementName {
        case "title":
            currentNewsItem?.newsTitle = newsTitle.editedNewsDateOrTitle()
            newsTitle = ""
        case "description":
            currentNewsItem?.shortDescription = newsDescription.editedNewsDescription()
            newsDescription = ""
        case "enclosure":
            currentNewsItem?.imageURL = newsImageUrl.editedNewsDateOrTitle()
            newsImageUrl = ""
        case "guid":
            currentNewsItem?.link = newsLink
            newsLink = ""
        case "pubDate":
            currentNewsItem?.date = newsDate.editedNewsDateOrTitle()
            newsDate = ""
        case "item":
            insideAnItem = false
            parsedNews.append(currentNewsItem!)
        default:
            break
        }
 
    }
    
    func parseData(data: Data) -> [NewsItem]{
        parser?.abortParsing()
        parser = XMLParser(data: data)
        parser?.delegate = self
        parser?.parse()
        return parsedNews
    }
    
        }



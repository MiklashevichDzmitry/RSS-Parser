//
//  News.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 1/5/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import Foundation
import UIKit

class NewsItem {
    
    var newsTitle: String?
    var shortDescription: String?
    var date: String?
    var link: String?
    var imageURL: String?
    var newsImage: Data?
    var fullDescription: String?
    var dateFormatter = DateFormatter()
    
    init() {
        
    }
    
    init? (newsTitle: String?, shortDescription: String?, date: String?, link: String?, imageURL: String?, newsImage: Data?, fullDescription: String?, dateFormatter: DateFormatter){
        
        self.newsTitle = newsTitle
        self.shortDescription = shortDescription
        self.fullDescription = fullDescription
        self.date = date
        self.link = link
        self.imageURL = imageURL
        self.newsImage = newsImage
        self.dateFormatter = dateFormatter
        dateFormatter.dateFormat = "EEE, dd MM yyy HH:mm"
        dateFormatter.locale = Locale(identifier: "US_en")
            
        }
    }

    
    


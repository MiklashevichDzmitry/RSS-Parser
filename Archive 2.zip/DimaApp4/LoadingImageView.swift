//
//  LoadingImageView.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 1/30/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import Foundation
import UIKit

class LoadingImageView: UIImageView {
 
    var spinner: UIActivityIndicatorView!
    
    override func awakeFromNib() {
        spinner = UIActivityIndicatorView.init(activityIndicatorStyle: .gray)
        spinner.backgroundColor = UIColor.green
        self.addSubview(spinner)
//        let viewSpinner = ["spinner": spinner]
//        var spinnerConstrains = [NSLayoutConstraint]()
//        let spinnerVerticalConstraint = NSLayoutConstraint.constraints(withVisualFormat: "V:|[spinner]|", options: [], metrics: nil, views: viewSpinner)
//        spinnerConstrains += spinnerVerticalConstraint
//        let spinnerHorizontalConstraint = NSLayoutConstraint.constraints(withVisualFormat: "|[spinner]|", options: [], metrics: nil, views: viewSpinner)
//        spinnerConstrains += spinnerHorizontalConstraint
//        NSLayoutConstraint.activate(spinnerConstrains)
//        addConstraints(spinnerConstrains)
    }
    
    public func imageFromUrl(urlString: String) {
        spinner.startAnimating()
        if let url = URL(string: urlString) {
            let urlRequest = URLRequest(url: url)
            let config = URLSessionConfiguration.default
            let session = URLSession(configuration: config)
             let task = session.dataTask(with: urlRequest, completionHandler: { (data, response, error) in
                if let data = data{
                    DispatchQueue.main.async{
                        //self.image = UIImage(data: data)
                        //self.spinner.stopAnimating()
                    }
                }
            }); task.resume()
}
        }
    }

        
   

//
//  CollectionViewCell.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 2/10/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var collectionImage: LoadingImageView!

}

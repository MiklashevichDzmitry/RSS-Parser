//
//  NewsTableViewController.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 1/5/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import UIKit

class NewsTableViewController: UITableViewController, NewsLoaderDelegate {
    
    var currentNews: [NewsItem]?
    var newsLoader: NewsLoader
    var parser: Parser
    
    required init?(coder aDecoder: NSCoder) {
        self.parser = Parser()
        self.newsLoader = NewsLoader()
        super.init(coder: aDecoder)
        self.newsLoader.delegate = self
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        reloadData()
        self.refreshControl?.addTarget(self, action: #selector(NewsTableViewController.reloadData), for: UIControlEvents.valueChanged)
        newsLoader.loadNews()
    }
    
    func reloadData() {
        newsLoader.loadNews()
    }
    
    func refreshUI() {
        
        tableView.reloadData()
        refreshControl?.endRefreshing()
       
    }

    func didLoadNews(news: [NewsItem]) {
        currentNews = news
        refreshUI()
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if let currentNews = currentNews{
            return currentNews.count
        } else {
            return 0
 
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "NewsTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? NewsTableViewCell else {
            fatalError("The dequeued cell is not an instance of NewsTableViewCell.")
        }
        
        let item = currentNews![indexPath.row]
        if let shortDescription = item.shortDescription{
            if let date = item.date{
                if let link = item.link{
                    if let newsTitle = item.newsTitle{
                        cell.shortDescriptionLable.text = shortDescription
                        cell.dateLabel.text = String(describing: date)
                        cell.linkLabel.text = link
                        //cell.newsImage.image = item.image
                        cell.titleLabel.text = newsTitle
                    }
                }
            }
        }else {
            print("")
        }
        
        return cell
        
    }
}












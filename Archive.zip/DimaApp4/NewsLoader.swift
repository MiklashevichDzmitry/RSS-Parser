//
//  NewsLoader.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 1/11/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import Foundation
import UIKit

class NewsLoader {
    
  
    
}

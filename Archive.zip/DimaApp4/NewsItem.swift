//
//  News.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 1/5/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import Foundation
import UIKit

class NewsItem {
    
    var newsTitle: String?
    var shortDescription: String?
    var date: String?
    var link: String?
    var image: String?
    var dateFormatter = DateFormatter()
    
    init() {
        
    }
    
    init? (newsTitle: String?, shortDescription: String?, date: String?, link: String?, image: String?, dateFormatter: DateFormatter){
        
        self.newsTitle = newsTitle
        self.shortDescription = shortDescription
        self.date = date
        self.link = link
        self.image = image
        self.dateFormatter = dateFormatter
        dateFormatter.dateFormat = "EEE, dd MM yyy HH:mm"
        dateFormatter.locale = Locale(identifier: "US_en")
            
        }
    }

    
    


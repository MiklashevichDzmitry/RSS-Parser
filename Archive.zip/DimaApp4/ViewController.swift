//
//  ViewController.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 12/29/16.
//  Copyright © 2016 Dzmitry Miklashevich. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {
    
    @IBOutlet weak var ScrollView: UIScrollView!
    
    @IBOutlet weak var ScrollViewBackground: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ScrollViewBackground.delegate = self
    
        
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
            
             let foregroundHeight = ScrollViewBackground.contentSize.height - ScrollViewBackground.bounds.height
             let percentageScroll = ScrollViewBackground.contentOffset.y / foregroundHeight
             let backgroundHeight = ScrollView.contentSize.height - scrollView.bounds.height
            
            scrollView.contentOffset = CGPoint(x: 0, y: backgroundHeight * percentageScroll)
        }
    }
}

    
    
    /*var scrollView: UIScrollView!
    var imageView: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageView = UIImageView(image: UIImage(named: "image.png"))
        
        scrollView = UIScrollView(frame: view.bounds)
        scrollView.backgroundColor = UIColor.white
        scrollView.contentSize = imageView.bounds.size
        scrollView.autoresizingMask = UIViewAutoresizing.flexibleWidth
        scrollView.autoresizingMask = UIViewAutoresizing.flexibleHeight
        scrollView.contentOffset = CGPoint(x: 1000, y: 450)
        scrollView.delegate = self
        
        scrollView.addSubview(imageView)
        view.addSubview(scrollView)
       
    }
*/
 







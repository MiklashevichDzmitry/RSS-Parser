//
//  File.swift
//  DimaApp4
//
//  Created by Dzmitry Miklashevich on 1/26/17.
//  Copyright © 2017 Dzmitry Miklashevich. All rights reserved.
//

import Foundation


protocol NewsLoaderDelegate {
    
    func didLoadNews(news: [NewsItem])

}

class NewsLoader {
    
   var parser: Parser
    
    init(){
        parser = Parser()
    }
    
    
    var delegate: NewsLoaderDelegate? = nil
    
    
    func loadNews(){
        
        let todoEndpoint: String = "http://news.tut.by/rss/index.rss"
        guard let url = URL(string: todoEndpoint) else {
            print("Error: cannot create URL")
            return
        }
        let urlRequest = URLRequest(url: url)
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        let task = session.dataTask(with: urlRequest, completionHandler: { (data, response, error) in
            if let data = data{
                let newsItems = self.parser.parseData(data: data)
                DispatchQueue.main.async {
                    self.delegate?.didLoadNews(news: newsItems)
                }
                
                if let error = error{
                    print("Error:\(error) + Description:\(error.localizedDescription)")
                    return
                }
                

            }
//             print("\(self.parser.parsedNews)")
            //print("\(String(data: data!, encoding: String.Encoding.utf8))")
            //print(error as Any)
            //print(response as Any)
            
        })
        
        task.resume()
    }
    
    
    
    /*
    func loadNews(){
     
        let image1 = UIImage(named: "1")
        let image2 = UIImage(named: "5")
        let image3 = UIImage(named: "6")
        
        if delegate != nil
            
        {
            
            guard let item1 = NewsItem(newsTitle: "Title1", shortDescription: "Hello1", date: Date(), link: "Me1", image: image1, dateFormatter: DateFormatter()) else {
                fatalError("oops")
            }
            guard let item2 = NewsItem(newsTitle: "Title2", shortDescription: "Hello2", date: Date(), link: "Me2", image: image2, dateFormatter: DateFormatter()) else{
                fatalError("oops")
            }
            guard let item3 = NewsItem(newsTitle: "Title3", shortDescription: "Hello3", date: Date(), link: "Me3", image: image3, dateFormatter: DateFormatter()) else{
                fatalError("oops")
            }
            */

        
    }
    


